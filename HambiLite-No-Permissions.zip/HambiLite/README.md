# Hambi Lite — independent Android demo

A standalone yellow/black Android app concept inspired by compact super-app dashboards. It does not impersonate or connect to Beeline/Hambi.

## Features
- Home, services, payments/notes, profile screens
- Uzbek, Russian and English UI switch
- Editable personal balance, internet remainder and phone number stored locally on device
- Service forms validate input and create a local reminder/history record
- No Android runtime permissions; no internet permission; no SIM, contacts, location, SMS, phone-call or payment access
- Payment records are local notes only. No real money transfer or operator balance retrieval is performed.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload the contents of this folder (including `.github`).
2. Open **Actions** → **Build Hambi Lite APK** → **Run workflow**.
3. When it finishes, download `HambiLite-debug-apk` from Artifacts and extract `app-debug.apk`.

The APK is unsigned for Play Store release (debug signed for local installation). This repository has not been built/tested on a physical Samsung device in this environment.
